<template>
  <div id="app">
    <router-view/>
    <my-footer></my-footer>
  </div>
</template>

