<template>
    <div class="control2">
        <div class="header">
            <p>训练计划+饮食指导</p>
        </div>
    </div>
</template>

<style>
.control2 .header{
    width: 100%;height: 8rem;
    background-image: url('../../public/img/index/control2_background.jpg');
    text-align: center;
    line-height: 8rem;
}
/* 怎么给背景图片设置透明度？？？
    .control2 .header::after{
    width: 100%;height: 8rem;
    opacity: 0.5;
    background-image: url('../../public/img/index/control2_background.jpg');    
    position: absolute;
    z-index: -999
} */
.control2 .header p{
    font-size: 2em;
    font-weight: bolder;
    font-family: monospace;
}
</style>
