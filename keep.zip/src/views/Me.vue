<template>
    <div class="me">
        me
        <my-footer></my-footer>
    </div>
</template>
<script>
    import myFooter from '../components/Footer'
    export default {
    components:{myFooter}
    }
</script>