<template>
    <div class="sport">
        sport
        <my-footer></my-footer>
    </div>
</template>
<script>
    import myFooter from '../components/Footer'
    export default {
    components:{myFooter}
    }
</script>