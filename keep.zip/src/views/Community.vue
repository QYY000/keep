<template>
  <div class="community">
    <h1>社区</h1>
    <!-- 底部导航栏 -->
    <my-footer></my-footer>
  </div>
</template>
<script>
import myFooter from '../components/Footer'
export default {
  components:{myFooter}
}
</script>
